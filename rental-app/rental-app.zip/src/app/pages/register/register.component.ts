import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'page-register',
    templateUrl: './register.component.html',
})
export class RegisterComponent implements OnInit {
    constructor(){}
    ngOnInit(){}
}