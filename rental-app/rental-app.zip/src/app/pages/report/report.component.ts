import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'page-report',
    templateUrl: './report.component.html',
})
export class ReportComponent implements OnInit {
    constructor(){}
    ngOnInit(){}
}