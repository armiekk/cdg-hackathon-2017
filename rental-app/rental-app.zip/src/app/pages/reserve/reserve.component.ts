import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'page-reserve',
    templateUrl: './reserve.component.html',
})
export class ReserveComponent implements OnInit {
    constructor(){}
    ngOnInit(){}
}