import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReserveRouterModule } from './reserve-router.module';

// page components
import { ReserveComponent } from './reserve.component';


@NgModule({
    imports: [
        CommonModule,
        ReserveRouterModule,
    ],
    declarations: [ReserveComponent],
})
export class ReserveModule { }