import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/primeng';

@Component({
    selector: 'page-search',
    templateUrl: './search.component.html',
})
export class SearchComponent implements OnInit {

    fareRange: SelectItem[] = [];

    constructor() { }
    ngOnInit() {
        this.fareRange = [
            { label: '0 - 3,000', value: 0 },
            { label: '3,001 - 6,000', value: 1 },
            { label: '6,001 - 10,000', value: 2 },
            { label: 'มากกว่า 10,000', value: 3 },
        ];
    }
}