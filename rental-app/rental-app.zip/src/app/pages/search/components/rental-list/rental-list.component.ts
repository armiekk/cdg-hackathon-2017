import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'comp-rental-list',
    templateUrl: './rental-list.component.html',
})
export class RentalListComponent implements OnInit {
    constructor() { }
    ngOnInit() { }
}