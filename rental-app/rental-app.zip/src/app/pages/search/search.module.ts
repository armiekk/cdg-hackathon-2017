import { NgModule, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchRouterModule } from './search-router.module';
import { AppShareModule } from '../../share/app-share.module';

// page components
import { SearchComponent } from './search.component';
import { RentalListComponent } from './components/rental-list/rental-list.component';

@NgModule({
    imports: [
        CommonModule,
        SearchRouterModule,
        AppShareModule,
    ],
    declarations: [
        SearchComponent,
        RentalListComponent,
    ],
})
export class SearchModule { }