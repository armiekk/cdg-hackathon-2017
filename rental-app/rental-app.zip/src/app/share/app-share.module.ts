import { NgModule } from '@angular/core';
import { DropdownModule, DataListModule, ButtonModule } from 'primeng/primeng';

@NgModule({
    imports: [
        DropdownModule, DataListModule, ButtonModule,
    ],
    exports: [
        DropdownModule, DataListModule, ButtonModule,
    ],
})
export class AppShareModule { }
